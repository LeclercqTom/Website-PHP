<?php

return $routes = [
    '/MiniProjet/starter_1/' => 'index.php',
    '/MiniProjet/starter_1/login' => 'login.php',
    '/MiniProjet/starter_1/register' => 'register.php',
    '/MiniProjet/starter_1/create' => 'createUser.php',
    '/MiniProjet/starter_1/connect' => 'connectUser.php',
    '/MiniProjet/starter_1/disconnect' => 'disconnect.php',
    '/MiniProjet/starter_1/profil' => 'profil.php',
    '/MiniProjet/starter_1/infoProfil' => 'infoProfil.php',
    '/MiniProjet/starter_1/editProfil' => 'editProfil.php',
    '/MiniProjet/starter_1/modifProfil' => 'modifProfil.php',
    
   
];
